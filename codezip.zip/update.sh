#!/bin/bash
cp /numConvert/numConverter /usr/bin/numConverter && cp /numConvert/math /usr/bin/math && cp update.sh /usr/bin/ucode.sh