Run this code with the python interpreter, make sure you have

1. pandas
2. numpy
3. sklearn
4. matplotlib

installed in order to run this code

as well as the heart.csv in the same folder (its all in the same zip)