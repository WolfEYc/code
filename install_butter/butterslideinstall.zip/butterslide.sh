sudo apt-get install libsfml-dev
sudo cp butterslide.exe /usr/bin/butterslide.exe
sudo cp arial.ttf /usr/bin/arial.ttf
sudo cp butter.png /usr/bin/butter.png
sudo cp butterslide.desktop /usr/share/applications/butterslide.desktop

